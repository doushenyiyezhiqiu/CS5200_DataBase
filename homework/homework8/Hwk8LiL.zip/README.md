To run these execution codes:
1) Open the terminal (or use Git Bash) and run "python hw8_LiL.py"
2) Enter your username in MySQL WorkBranch
3) Enter your password
4) Enter a character's name you want to track (All characters will be shown before this step) 