CREATE DATABASE IF NOT EXISTS `Regional_Schools`;
USE Regional_Schools;

CREATE TABLE IF not exists school(
school_identification_number INT auto_increment,
name VARCHAR(100) not null unique,
address VARCHAR(255) not null,
phone_number VARCHAR(10) not null,
principal_name VARCHAR(100) not null unique,
principal_start_date DATE NOT NULL,
constraint school_pk PRIMARY KEY (school_identification_number)
);


CREATE TABLE IF not exists teacher(
national_insurance_number INT not null,
name VARCHAR(100) not null,
/* Sex:
0 stands for not know, 
1 stands for male, 
2 stands for female
9 stands for not applicable*/
sex INT not null check(sex = 0 or sex = 1 or sex = 2 or sex = 9), 
qualification VARCHAR(200) not null,
is_principal BINARY not null,
school_name VARCHAR(100) not null,
constraint teacher_pk primary key (national_insurance_number),
foreign key (school_name) references 
	school(name) On update cascade on delete restrict,
foreign key (name) references 
	school(principal_name) On update cascade on delete restrict
);


CREATE TABLE IF not exists pupil(
pupil_id INT not null,
name VARCHAR(100) not null,
/* Sex:
0 stands for not know, 
1 stands for male, 
2 stands for female
9 stands for not applicable*/
sex INT not null check(sex = 0 or sex = 1 or sex = 2 or sex = 9), 
date_of_birth DATE not null,
school_name VARCHAR(100) not null,
constraint birth_constraint check(date_of_birth > '1900-01-01'),
constraint pupil_pk primary key (pupil_id),
foreign key (school_name) references 
	school(name) On update cascade on delete restrict
);

CREATE TABLE IF not exists subject(
subject_title VARCHAR(100) not null,
subject_type VARCHAR(64) not null,
constraint subject_pk primary key (subject_title)
);

CREATE TABLE IF not exists subject_teacher_team(
subject_title VARCHAR(100) not null,
teacher_name VARCHAR(100) not null,
teacher_national_insurance_number INT not null,
teacher_working_hours INT DEFAULT 0,
constraint subject_teacher_team_pk primary key (subject_title),
foreign key (subject_title) references 
	subject(subject_title) On update cascade on delete restrict,
foreign key (teacher_national_insurance_number) references 
	teacher(national_insurance_number) On update cascade on delete restrict
);


CREATE DATABASE IF NOT EXISTS `pet_clinic`;
USE pet_clinic;

CREATE TABLE IF not exists clinic(
clinic_no INT auto_increment,
manager_name VARCHAR(100) not null,
manager_staff_no INT not null unique,
constraint clinic_pk PRIMARY KEY (clinic_no)
);

CREATE TABLE IF not exists staff(
staff_no INT auto_increment,
clinic_no INT not null,
constraint staff_pk PRIMARY KEY (staff_no),
foreign key (clinic_no) references 
	clinic(clinic_no) On update cascade on delete restrict,
foreign key (staff_no) references 
	clinic(manager_staff_no) On update cascade on delete restrict
);

CREATE TABLE IF not exists owner(
owner_no INT auto_increment,
owner_name VARCHAR(100) NOT NULL,
constraint owner_pk PRIMARY KEY (owner_no)
);

CREATE TABLE IF not exists pet(
pet_no INT auto_increment,
pet_name VARCHAR(100) not null,
registered_clinic_name VARCHAR(100) not null,
registered_clinic_no INT not null,
owner_name VARCHAR(100) not null,
owner_no INT not null,
constraint pet_pk PRIMARY KEY (pet_no),
foreign key (owner_no) references 
	owner(owner_no) On update cascade on delete restrict,
foreign key (registered_clinic_no) references 
	clinic(clinic_no) On update cascade on delete restrict
);

CREATE TABLE IF not exists examination(
examination_no INT auto_increment,
pet_name VARCHAR(100) not null,
pet_no INT not null,
staff_name VARCHAR(100) not null,
staff_no INT not null,
constraint examination_pk PRIMARY KEY (examination_no),
foreign key (pet_no) references 
	pet(pet_no) On update cascade on delete restrict,
foreign key (staff_no) references 
	staff(staff_no) On update cascade on delete restrict
);

CREATE TABLE IF not exists treatment(
treat_no INT auto_increment,
pet_name VARCHAR(100) not null,
pet_no INT not null,
examination_no INT not null,
constraint treatmenttreatment_pk PRIMARY KEY (treat_no),
foreign key (pet_no) references 
	pet(pet_no) On update cascade on delete restrict,
foreign key (examination_no) references 
	examination(examination_no) On update cascade on delete restrict
);


CREATE DATABASE IF NOT EXISTS `cleaning_company`;
USE cleaning_company;

CREATE TABLE IF not exists client(
client_name VARCHAR(100) NOT NULL,
client_type BINARY not null,
constraint client_pk PRIMARY KEY (client_name)
);

CREATE TABLE IF not exists staff(
staff_id INT auto_increment,
staff_name VARCHAR(100) NOT NULL,
staff_type BINARY not null,
constraint staff_pk PRIMARY KEY (staff_id)
);

CREATE TABLE IF not exists administrative_staff(
staff_id INT auto_increment,
staff_name VARCHAR(100) NOT NULL,
constraint administrative_staff_pk PRIMARY KEY (staff_id),
foreign key (staff_id) references 
	staff(staff_id) On update cascade on delete restrict
);

CREATE TABLE IF not exists day_to_day_office_work(
supervisor_id INT not null,
work_type INT not null, /*1 -- simple office work; 2-- answer phone; 3-- maitain schedule; 4-- ensure specialist equipment maintained*/
constraint staff_pk PRIMARY KEY (supervisor_id),
foreign key (supervisor_id) references 
	administrative_staff(staff_id) On update cascade on delete restrict
);


CREATE TABLE IF not exists cleaning_group(
group_id INT auto_increment,
supervisor_staff_id INT NOT NULL,
constraint group_id_pk PRIMARY KEY (group_id)
);

CREATE TABLE IF not exists cleaning_staff(
staff_id INT not null,
staff_name VARCHAR(100) NOT NULL,
group_id INT not null,
constraint cleaning_staff_pk PRIMARY KEY (staff_id),
foreign key (staff_id) references 
	staff(staff_id) On update cascade on delete restrict,
foreign key (group_id) references 
	cleaning_group(group_id) On update cascade on delete restrict
);



CREATE TABLE IF not exists job(
job_id INT auto_increment,
working_time VARCHAR(200) NOT NULL,
client_name VARCHAR(100) NOT NULL,
assessment_administrative_staff_name VARCHAR(100) NOT NULL,
assessment_administrative_staff_id INT NOT NULL,
clearning_group_id INT NOT NULL,
required_working_hours INT default 0,
required_special_equipment INT default 0,
working_quality INT default 0, /* 0 means the worst and 10 means the best*/
constraint job_pk PRIMARY KEY (job_id),
foreign key (assessment_administrative_staff_id) references 
	administrative_staff(staff_id) On update cascade on delete restrict,
foreign key (clearning_group_id) references 
	cleaning_group(group_id) On update cascade on delete restrict,
foreign key (client_name) references 
	client(client_name) On update cascade on delete restrict
);
