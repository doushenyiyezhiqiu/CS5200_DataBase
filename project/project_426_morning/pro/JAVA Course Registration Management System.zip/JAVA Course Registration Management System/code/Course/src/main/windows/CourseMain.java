package main.windows;

import main.until.ConnectionDB;

public class CourseMain {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        LoginWindows loginWindows = new LoginWindows();
        ConnectionDB db = new ConnectionDB("root", "scb78377837", "project");//Database name, password and database name
    }

}
