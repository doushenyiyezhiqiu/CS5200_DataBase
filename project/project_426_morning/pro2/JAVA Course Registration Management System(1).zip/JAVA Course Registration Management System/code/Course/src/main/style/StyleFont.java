package main.style;

import java.awt.*;

public class StyleFont {

    public static Font titleFont = new Font("Times New Roman", Font.BOLD, 26);//标题样式

    public static Font loginFont = new Font("Times New Roman", Font.BOLD, 18);//登录按钮样式

    public static Font Item = new Font("Times New Roman", Font.PLAIN, 18);//点击条样式
}
