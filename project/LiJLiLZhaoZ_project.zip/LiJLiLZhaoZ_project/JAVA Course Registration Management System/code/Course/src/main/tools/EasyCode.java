package main.tools;

import javax.swing.*;

public class EasyCode {

    public static void setTileIcon(JFrame jFrame) {

        jFrame.setTitle("Course Registration");
        jFrame.setIconImage(new ImageIcon("code/Course/src/WindowsIcon/windowsIcon.png").getImage());
    }
}
