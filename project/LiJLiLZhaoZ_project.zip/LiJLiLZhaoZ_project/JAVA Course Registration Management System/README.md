To run the codes:
(1)	Open the directory in an IDE (make sure you download IDEA and have a java environment)
(2)	Make sure mysql-connector-java.jar is added to dependency
(3)	Run the "finalDatabase_schema.sql" in MySQL workbench and make sure the database is added to your scheme
(4)	Find "CourseMain.java" (in window directory), change the account, password and dbName parameters based on your database setup, otherwise the program cannot be connected to the database.
(5)	Run “CourseMain.java” and a log in window will be started. You can use the accounts in Instruction.txt or create new accounts in administration mode.

To log in account:
manager 
account：root 
password:root

student 
account:  2021592 
password:2021592

teacher 
account: 12021591 
password:12021591